<?php





?>

<section class="ftco-section bg-light" id="skills-section">
    <div class="container">
        <div class="row justify-content-center pb-5">
            <div class="col-md-12 heading-section text-center ftco-animate">
                <h1 class="mb-4">Thank You</h1>
                <p>Will respond as soon as possible</p>
            </div>
        </div>
    </div>
</section>